/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author APRENDIZ
 */
public class Programa {
    int codprograma; 
    String nomprograma; 

    public Programa() {
    }

    public int getCodprograma() {
        return codprograma;
    }

    public void setCodprograma(int codprograma) {
        this.codprograma = codprograma;
    }

    public String getNomprograma() {
        return nomprograma;
    }

    public void setNomprograma(String nomprograma) {
        this.nomprograma = nomprograma;
    }
    
}
