
package model;


public class Aprendiz {
    int id; 
    int Docu,Numcontacto;
    String Nombrea,Apellidoa,Correoa;  

    public Aprendiz() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDocu() {
        return Docu;
    }

    public void setDocu(int Docu) {
        this.Docu = Docu;
    }

    public int getNumcontacto() {
        return Numcontacto;
    }

    public void setNumcontacto(int Numcontacto) {
        this.Numcontacto = Numcontacto;
    }

    public String getNombrea() {
        return Nombrea;
    }

    public void setNombrea(String Nombrea) {
        this.Nombrea = Nombrea;
    }

    public String getApellidoa() {
        return Apellidoa;
    }

    public void setApellidoa(String Apellidoa) {
        this.Apellidoa = Apellidoa;
    }

    public String getCorreoa() {
        return Correoa;
    }

    public void setCorreoa(String Correoa) {
        this.Correoa = Correoa;
    }
    
    
    
}
