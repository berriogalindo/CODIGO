
package model;

public class Ficha 
{
    private int CodFicha;
    private int Cantiaprendices;
    private int Codprograma;
    private int Codaprendiz;
    
    public Ficha(){
    
    }

    public int getCodFicha() {
        return CodFicha;
    }

    public void setCodFicha(int CodFicha) {
        this.CodFicha = CodFicha;
    }

    public int getCantiaprendices() {
        return Cantiaprendices;
    }

    public void setCantiaprendices(int Cantiaprendices) {
        this.Cantiaprendices = Cantiaprendices;
    }

    public int getCodprograma() {
        return Codprograma;
    }

    public void setCodprograma(int Codprograma) {
        this.Codprograma = Codprograma;
    }

    public int getCodaprendiz() {
        return Codaprendiz;
    }

    public void setCodaprendiz(int Codaprendiz) {
        this.Codaprendiz = Codaprendiz;
    }
   
}
