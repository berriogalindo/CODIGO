/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeldao;

import Interfaz.Meficha;
import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Ficha;

public class FichaDao implements Meficha
{
    Ficha fi=new Ficha();
    Conexion cn= new Conexion(); 
    Connection con;
    PreparedStatement ps; 
    ResultSet rs; 
    
    
    
    
    @Override
    public Ficha list(int cod) {
       String sql= "select * from ficha where codficha ="+cod;
        try {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while (rs.next()) {
                fi.setCodFicha(rs.getInt("codficha"));
                fi.setCantiaprendices(rs.getInt("cantiaprendices")); 
                fi.setCodprograma(rs.getInt("codprograma"));  
                fi.setCodaprendiz(rs.getInt("doapre"));
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Ficha no encontrada");
        }
        return fi;
    }

    @Override
    public List listaFichas() {
        ArrayList<Ficha> lista = new ArrayList<Ficha>(); 
        String sql ="select * from ficha";  
          try{
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery(); 
            while(rs.next())
            {
            Ficha fi =new Ficha(); 
            fi.setCodFicha(rs.getInt("codficha"));
            fi.setCantiaprendices(rs.getInt("cantiaprendices")); 
            fi.setCodprograma(rs.getInt("codprograma"));  
            fi.setCodaprendiz(rs.getInt("doapre")); 
            
            
            
            lista.add(fi);
            
            }
                
                
        }catch(Exception e)
        {
        }
        return lista;    }
    

    @Override
    public boolean registrarficha(Ficha fi)
    {
        String sql= "insert into ficha(codficha,cantiaprendices,codprograma,doapre)values('"+fi.getCodFicha()+"','"+fi.getCantiaprendices()+"','"+fi.getCodprograma()+"','"+fi.getCodaprendiz()+"')";
        try 
        {
            con=cn.getConnection();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Ficha resgistrada");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Ficha no resgistrada");
        }
        return false;
    }

    @Override
    public boolean actualizarficha(Ficha fi) {
        String sql="insert into ficha(codficha,cantiaprendices,codprograma,doapre)values('"+fi.getCodFicha()+"','"+fi.getCantiaprendices()+"','"+fi.getCodprograma()+"','"+fi.getCodaprendiz()+"')";   
    try{
            con=cn.getConnection(); 
            ps=con.prepareStatement(sql); 
            ps.executeUpdate(); 
        }catch(Exception e){
        
        }
        return false;
    
    }

    @Override
    public boolean eliminarficha(int cod) {
       String sql="insert into ficha(codficha,cantiaprendices,codprograma,doapre)values('"+fi.getCodFicha()+"','"+fi.getCantiaprendices()+"','"+fi.getCodprograma()+"','"+fi.getCodaprendiz()+"')"; 
       
        return false;
    }

    public void registrarfi(FichaDao fdao) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean eliminarfi(int id) {
        String sql="delete from ficha where id="+id;
        try {
            con=cn.getConnection(); 
            ps=con.prepareStatement(sql); 
            ps.executeUpdate();
        } catch (Exception e) {
            
        }
        return false;
        
    }

}